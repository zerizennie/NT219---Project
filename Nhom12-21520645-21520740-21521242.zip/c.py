import cv2 as cv
import paho.mqtt.client as mqtt
import base64
import time
import numpy as np


broker = 'broker.hivemq.com'
port = 1883
topic = "python/vid"


cap = cv.VideoCapture("C:\\Users\\Admin\\OneDrive\\Downloads\\The Phases of the Moon in Six Seconds.mp4")
# Phao-MQTT Clinet
client = mqtt.Client()
# Establishing Connection with the Broker
client.connect(broker)
try:
      while True:
            start = time.time()
  # Read Frame
            time.sleep(3)
            ret, frame = cap.read()
           
              # Encoding the Frame
            _, buffer = cv.imencode('.jpg', frame)
  # Converting into encoded bytes
            jpg_as_text = base64.b64encode(buffer)
  # Publishig the Frame on the Topic home/server
            client.publish(topic, jpg_as_text)
            end = time.time()
            t = end - start
            fps = 1/t
            print(fps)
except:
    cap.release()
    client.disconnect()
    print("\nNow you can restart fresh")